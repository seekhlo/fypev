import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'cards.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../SendFile/senderUI.dart';

class DashBoard extends StatelessWidget {
  const DashBoard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(


      home: Scaffold(
        appBar: AppBar(
          title: Text('Dashboard'),
        ),
        body: SafeArea(
          child: Center(
            child: Column(
              children: [
                Expanded(child:Container()),
                Expanded(flex: 2,
                  child: Column(
                    children: <Widget>[


                      Expanded(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget>[
                            const SizedBox(
                              height: 50,
                            ),
                            Expanded(
                                child: usercards(CardImage: Expanded(child: Image
                                    .asset("assets/send.png")), CardText: "Send File", onPress: (){
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (context) => senderUI()),
                                  );
                                })
                            ),
                            Expanded(
                                child: usercards(CardImage: Expanded(child: Image.asset("assets/recieve.png"),),
                                    CardText: "Recieve File" , onPress:(){})
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget>[
                            const SizedBox(
                              height: 50,


                            ),
                            Expanded(
                                child: usercards(CardImage: Expanded(child: Image
                                    .asset("report.png")),
                                    CardText: "Records/Reports",onPress:(){}),
                            ),
                            Expanded(
                                child: usercards(CardImage: Expanded(child: Image
                                    .asset("notification.png")), CardText: "Pending",onPress:(){})
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget>[
                            const SizedBox(
                              height: 50,
                            ),
                            Expanded(
                                child: usercards(CardImage: Expanded(child: Image
                                    .asset(
                                  "assets/settings.png", fit: BoxFit.fitHeight,)),
                                    CardText: "Settings",onPress:(){})
                            ),
                            Expanded(
                                child: usercards(CardImage: Expanded(child: Image
                                    .asset("assets/profile.png")),
                                    CardText: "Profile",onPress:(){})
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
